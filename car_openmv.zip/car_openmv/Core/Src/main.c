/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "TYS_OLED.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BEEP_ON     HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, RESET)
#define BEEP_OFF    HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, SET)
#define BEEP_TOGGLE HAL_GPIO_TogglePin(BEEP_GPIO_Port, BEEP_Pin)

#define LIGHT_YELLOW_ON     HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, SET)
#define LIGHT_YELLOW_OFF    HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, RESET)
#define LIGHT_YELLOW_TOGGLE HAL_GPIO_TogglePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin)

#define LIGHT_GREEN_ON     HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, SET)
#define LIGHT_GREEN_OFF    HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, RESET)
#define LIGHT_GREEN_TOGGLE HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin)

#define LIGHT_RED_ON     HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, SET)
#define LIGHT_RED_OFF    HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, RESET)
#define LIGHT_RED_TOGGLE HAL_GPIO_TogglePin(LED_RED_GPIO_Port, LED_RED_Pin)

#define MOTOR_STOP    0x00
#define MOTOR_FORWARD 0x01
#define MOTOR_RIGHT   0x02
#define MOTOR_LEFT    0x03
#define MOTOR_BACK    0x04
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

PCD_HandleTypeDef hpcd_USB_FS;

osThreadId DisplayTaskHandle;
osThreadId SenseTaskHandle;
osThreadId LogicTaskHandle;
/* USER CODE BEGIN PV */
// Light
uint8_t Light_Start;
uint8_t Light_L, Light_M, Light_R;
// Encoder
int32_t Speed_A, Speed_B;
int32_t Speed_A_Target, Speed_B_Target;
int32_t Speed_A_Bias, Speed_B_Bias;
// Motor
uint8_t  Motor_Dir;
int32_t PWM_A, PWM_B;
// OpenMV
uint8_t OpenMV_Start;
uint8_t OpenMV_Num, OpenMV_Dir;
// OLED
uint8_t Book_Num;
uint8_t Page_Num;
// Chest
uint8_t Chest;
// PID
uint8_t PID_Start;
int32_t ERR_A_Last_0, ERR_A_Last_1, ERR_A_Last_2;
int32_t ERR_B_Last_0, ERR_B_Last_1, ERR_B_Last_2;
int32_t PID_P = 600, PID_I = 1200, PID_D = 150;
// UART
uint8_t UART1_Temp[8];
uint8_t UART1_Rx_Flag = 0;
uint8_t UART1_Rx_Cnt = 0;
uint8_t UART1_Byte = 0x00;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USB_PCD_Init(void);
void StartDisplayTask(void const * argument);
void StartSenseTask(void const * argument);
void StartLogicTask(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  switch (GPIO_Pin) {
    case KEY_1_Pin:
      HAL_Delay(100);
      if(HAL_GPIO_ReadPin(KEY_1_GPIO_Port, KEY_1_Pin) == RESET) Page_Num++;
      break;
    case KEY_2_Pin:
      HAL_Delay(100);
      if(HAL_GPIO_ReadPin(KEY_2_GPIO_Port, KEY_2_Pin) == RESET) Book_Num++;
      break;
    case KEY_3_Pin:
      HAL_Delay(100);
      if(HAL_GPIO_ReadPin(KEY_3_GPIO_Port, KEY_3_Pin) == RESET){
        if(Book_Num == 0x01 && Page_Num == 0x00) LIGHT_RED_TOGGLE;
        if(Book_Num == 0x01 && Page_Num == 0x01) LIGHT_GREEN_TOGGLE;
        if(Book_Num == 0x01 && Page_Num == 0x02) LIGHT_YELLOW_TOGGLE;
        if(Book_Num == 0x01 && Page_Num == 0x03) BEEP_TOGGLE;
        if(Book_Num == 0x01 && Page_Num == 0x04) Motor_Dir++;
      }
      break;
  }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
  if (huart->Instance == USART1) {
    UART1_Temp[UART1_Rx_Cnt] = UART1_Byte;
    UART1_Rx_Cnt++;
    if(UART1_Byte == 0x7f) UART1_Rx_Flag = 1;
    HAL_UART_Receive_IT(&huart1, &UART1_Byte, 1);
  }
}

void Go_Forward(){
  Speed_A_Target = 100;
  Speed_B_Target = 100;
  Motor_Dir = MOTOR_FORWARD;
  while(Light_L == RESET && Light_R == RESET){
    osDelay(100);
  }
  osDelay(200);
  Motor_Dir = MOTOR_STOP;
}

void Go_Right() {
  Speed_A_Target = 100;
  Speed_B_Target = 100;
  Motor_Dir = MOTOR_RIGHT;
  osDelay(500);
  while(Light_M == RESET){
    osDelay(100);
  }
  Motor_Dir = MOTOR_STOP;
}

void Go_Left() {
  Speed_A_Target = 100;
  Speed_B_Target = 100;
  Motor_Dir = MOTOR_LEFT;
  osDelay(500);
  while(Light_M == RESET){
    osDelay(100);
  }
  Motor_Dir = MOTOR_STOP;
}

void Go_Forward_Time(uint32_t time){
  Speed_A_Target = 100;
  Speed_B_Target = 100;
  Motor_Dir = MOTOR_FORWARD;
  Light_Start = 0x00;
  osDelay(1300);
  Light_Start = 0x01;
  osDelay(time - 2600);
  Light_Start = 0x00;
  osDelay(1300);
  Motor_Dir = MOTOR_STOP;
  osDelay(1000);
}

void Go_Right_Time() {
  Speed_A_Target = 100;
  Speed_B_Target = 100;
  Motor_Dir = MOTOR_RIGHT;
  osDelay(1250);
  Motor_Dir = MOTOR_STOP;
  osDelay(1000);
}

void Go_Left_Time() {
  Speed_A_Target = 100;
  Speed_B_Target = 100;
  Motor_Dir = MOTOR_LEFT;
  osDelay(1250);
  Motor_Dir = MOTOR_STOP;
  osDelay(1000);
}

void Go_Back_Time() {
  Speed_A_Target = 100;
  Speed_B_Target = 100;
  Motor_Dir = MOTOR_LEFT;
  osDelay(2200);
  Motor_Dir = MOTOR_STOP;
  osDelay(1000);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USB_PCD_Init();
  /* USER CODE BEGIN 2 */
  OLED_Init();
  OLED_Clear();
  OLED_Display_On();

  HAL_TIM_Encoder_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_Encoder_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_2);

  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

  HAL_UART_Receive_IT(&huart1, UART1_Temp, 1);
  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of DisplayTask */
  osThreadDef(DisplayTask, StartDisplayTask, osPriorityNormal, 0, 128);
  DisplayTaskHandle = osThreadCreate(osThread(DisplayTask), NULL);

  /* definition and creation of SenseTask */
  osThreadDef(SenseTask, StartSenseTask, osPriorityIdle, 0, 128);
  SenseTaskHandle = osThreadCreate(osThread(SenseTask), NULL);

  /* definition and creation of LogicTask */
  osThreadDef(LogicTask, StartLogicTask, osPriorityIdle, 0, 128);
  LogicTaskHandle = osThreadCreate(osThread(LogicTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 10;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 10;
  if (HAL_TIM_Encoder_Init(&htim1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 10;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 10;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 72-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USB Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_PCD_Init(void)
{

  /* USER CODE BEGIN USB_Init 0 */

  /* USER CODE END USB_Init 0 */

  /* USER CODE BEGIN USB_Init 1 */

  /* USER CODE END USB_Init 1 */
  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_Init 2 */

  /* USER CODE END USB_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LIGHT_ONBOARD_Pin|OLED_RST_Pin|OLED_CMD_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, MOTOR_A_1_Pin|MOTOR_A_2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, MOTOR_B_1_Pin|MOTOR_B_2_Pin|LED_YELLOW_Pin|LED_GREEN_Pin
                          |LED_RED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : LIGHT_ONBOARD_Pin OLED_RST_Pin OLED_CMD_Pin */
  GPIO_InitStruct.Pin = LIGHT_ONBOARD_Pin|OLED_RST_Pin|OLED_CMD_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : MOTOR_A_1_Pin MOTOR_A_2_Pin */
  GPIO_InitStruct.Pin = MOTOR_A_1_Pin|MOTOR_A_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : MOTOR_B_1_Pin MOTOR_B_2_Pin LED_YELLOW_Pin LED_GREEN_Pin
                           LED_RED_Pin BEEP_Pin */
  GPIO_InitStruct.Pin = MOTOR_B_1_Pin|MOTOR_B_2_Pin|LED_YELLOW_Pin|LED_GREEN_Pin
                          |LED_RED_Pin|BEEP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : KEY_1_Pin KEY_2_Pin KEY_3_Pin */
  GPIO_InitStruct.Pin = KEY_1_Pin|KEY_2_Pin|KEY_3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : LIGHT_B_Pin */
  GPIO_InitStruct.Pin = LIGHT_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(LIGHT_B_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LIGHT_A_Pin LIGHT_C_Pin */
  GPIO_InitStruct.Pin = LIGHT_A_Pin|LIGHT_C_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : CHEST_Pin */
  GPIO_InitStruct.Pin = CHEST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(CHEST_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDisplayTask */
/**
  * @brief  Function implementing the DisplayTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDisplayTask */
void StartDisplayTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
    switch (Book_Num) {
      case 0x00:
        switch (Page_Num) {
          case 0x00:
            OLED_ShowString(0, 0, "  Motor  Speed  ");
            OLED_ShowString(0, 2, "Speed_A||Speed_B");
            OLED_ShowString(0, 4, "       ||       ");
            OLED_ShowString(0, 6, "Sensor_Page 1//5");

            OLED_ShowNum(10, 4, Speed_A, 4, 16);
            OLED_ShowNum(80, 4, Speed_B, 4, 16);
            break;
          case 0x01:
            OLED_ShowString(0, 0, "   Motor PWM    ");
            OLED_ShowString(0, 2, " PWM_A || PWM_B ");
            OLED_ShowString(0, 4, "       ||       ");
            OLED_ShowString(0, 6, "Sensor_Page 2//5");

            OLED_ShowNum(10, 4, PWM_A, 4, 16);
            OLED_ShowNum(80, 4, PWM_B, 4, 16);
            break;
          case 0x02:
            OLED_ShowString(0, 0, "     Light      ");
            OLED_ShowString(0, 2, "Left| Mid |Right");
            OLED_ShowString(0, 4, "    |     |     ");
            OLED_ShowString(0, 6, "Sensor_Page 3//5");

            OLED_ShowNum(00, 4, Light_L, 4, 16);
            OLED_ShowNum(40, 4, Light_M, 4, 16);
            OLED_ShowNum(90, 4, Light_R, 4, 16);
            break;
          case 0x03:
            OLED_ShowString(0, 0, "     Chest      ");
            OLED_ShowString(0, 2, "    Medicine    ");
            OLED_ShowString(0, 4, "                ");
            OLED_ShowString(0, 6, "Sensor_Page 4//5");

            OLED_ShowNum(45, 4, Chest, 4, 16);
            break;
          case 0x04:
            OLED_ShowString(0, 0, "     OpenMV     ");
            OLED_ShowString(0, 2, "  Num  ||  Dir  ");
            OLED_ShowString(0, 4, "       ||       ");
            OLED_ShowString(0, 6, "Sensor_Page 5//5");

            OLED_ShowNum(10, 4, OpenMV_Num, 4, 16);
            OLED_ShowNum(80, 4, OpenMV_Dir, 4, 16);
            break;
          default:
            Page_Num = 0x00;
            break;
        }
        break;
      case 0x01:
        switch (Page_Num) {
          case 0x00:
            OLED_ShowString(0, 0, "    Red Light   ");
            OLED_ShowString(0, 2, "      State     ");
            OLED_ShowString(0, 4, "ABCDEFG||JKLMNOP");
            OLED_ShowString(0, 6, "Setting_Page1//5");
            break;
          case 0x01:
            OLED_ShowString(0, 0, "   Green Light  ");
            OLED_ShowString(0, 2, "      State     ");
            OLED_ShowString(0, 4, "ABCDEFG||JKLMNOP");
            OLED_ShowString(0, 6, "Setting_Page2//5");
            break;
          case 0x02:
            OLED_ShowString(0, 0, "  Yellow Light  ");
            OLED_ShowString(0, 2, "      State     ");
            OLED_ShowString(0, 4, "ABCD|FGHIJ|LMNOP");
            OLED_ShowString(0, 6, "Setting_Page3//5");
            break;
          case 0x03:
            OLED_ShowString(0, 0, "      Beep      ");
            OLED_ShowString(0, 2, "      State     ");
            OLED_ShowString(0, 4, "ABCDEFGHIJKLMNOP");
            OLED_ShowString(0, 6, "Setting_Page4//5");
            break;
          case 0x04:
            OLED_ShowString(0, 0, "     OpenMV     ");
            OLED_ShowString(0, 2, "  Num  ||  Dir  ");
            OLED_ShowString(0, 4, "ABCDEFG||JKLMNOP");
            OLED_ShowString(0, 6, "Setting_Page5//5");
            break;
          default:
            Page_Num = 0x00;
            break;
        }
        break;
      default:
        Book_Num = 0x00;
        break;
    }

    osDelay(100);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartSenseTask */
/**
* @brief Function implementing the SenseTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartSenseTask */
void StartSenseTask(void const * argument)
{
  /* USER CODE BEGIN StartSenseTask */
  /* Infinite loop */
  for(;;)
  {
    // Get Motor Speed
    Speed_B = __HAL_TIM_GET_COUNTER(&htim1);
    if(Speed_B > 10000) Speed_B = 65535 - Speed_B;
    Speed_A = __HAL_TIM_GET_COUNTER(&htim2);
    if(Speed_A > 10000) Speed_A = 65535 - Speed_A;
    __HAL_TIM_SET_COUNTER(&htim1, 0x0000);
    __HAL_TIM_SET_COUNTER(&htim2, 0x0000);
    // Calculate PID
    if(PID_Start){
      ERR_A_Last_2 = ERR_A_Last_1;
      ERR_A_Last_1 = ERR_A_Last_0;
      ERR_A_Last_0 = Speed_A_Target + Speed_A_Bias - Speed_A;
      ERR_B_Last_2 = ERR_B_Last_1;
      ERR_B_Last_1 = ERR_B_Last_0;
      ERR_B_Last_0 = Speed_B_Target + Speed_B_Bias - Speed_B;
      PWM_A += 0.0005 * (PID_P * (ERR_A_Last_0 - ERR_A_Last_1) +
                        PID_I * ERR_A_Last_0 +
                        PID_D * (ERR_A_Last_0 - 2 * ERR_A_Last_1 + ERR_A_Last_2));
      PWM_B += 0.0005 * (PID_P * (ERR_B_Last_0 - ERR_B_Last_1) +
                        PID_I * ERR_B_Last_0 +
                        PID_D * (ERR_B_Last_0 - 2 * ERR_B_Last_1 + ERR_B_Last_2));
    }
    // Get Light Left Mid Right
    Light_L = HAL_GPIO_ReadPin(LIGHT_C_GPIO_Port, LIGHT_C_Pin);
    Light_M = HAL_GPIO_ReadPin(LIGHT_A_GPIO_Port, LIGHT_A_Pin);
    Light_R = HAL_GPIO_ReadPin(LIGHT_B_GPIO_Port, LIGHT_B_Pin);
    if(Light_Start){
      if(Light_R == SET) Speed_A_Bias = 50;
      else Speed_A_Bias = 0;
      if(Light_L == SET) Speed_B_Bias = 50;
      else Speed_B_Bias = 0;
    } else{
      Speed_A_Bias = 0;
      Speed_B_Bias = 0;
    }
    // Get Medicine Chest
    Chest = HAL_GPIO_ReadPin(CHEST_GPIO_Port, CHEST_Pin);
    // Get OpenMV
    if(UART1_Rx_Flag){
//      if(OpenMV_Start){
        OpenMV_Num = UART1_Temp[2];
        OpenMV_Dir = UART1_Temp[3];
//      }else{
//        OpenMV_Num = 0;
//        OpenMV_Dir = 0;
//      }
      UART1_Temp[7] = 0x00;
      UART1_Rx_Cnt = 0;
      UART1_Rx_Flag = 0;
    }
    // Write Speed
    switch (Motor_Dir) {
      case MOTOR_STOP:
        PID_Start = 0x00;
        Light_Start = 0x00;
        OpenMV_Start = 0x00;
        PWM_A = 0;
        PWM_B = 0;
        Speed_A_Target = 0;
        Speed_B_Target = 0;
        Speed_A_Bias = 0;
        Speed_B_Bias = 0;
        HAL_GPIO_WritePin(MOTOR_A_1_GPIO_Port, MOTOR_A_1_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_A_2_GPIO_Port, MOTOR_A_2_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_B_1_GPIO_Port, MOTOR_B_1_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_B_2_GPIO_Port, MOTOR_B_2_Pin, SET);
        break;
      case MOTOR_FORWARD:
        PID_Start = 0x01;
        Light_Start = 0x01;
        OpenMV_Start = 0x01;
        HAL_GPIO_WritePin(MOTOR_A_1_GPIO_Port, MOTOR_A_1_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_A_2_GPIO_Port, MOTOR_A_2_Pin, RESET);
        HAL_GPIO_WritePin(MOTOR_B_1_GPIO_Port, MOTOR_B_1_Pin, RESET);
        HAL_GPIO_WritePin(MOTOR_B_2_GPIO_Port, MOTOR_B_2_Pin, SET);
        break;
      case MOTOR_RIGHT:
        PID_Start = 0x01;
        Light_Start = 0x00;
        OpenMV_Start = 0x00;
        HAL_GPIO_WritePin(MOTOR_A_1_GPIO_Port, MOTOR_A_1_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_A_2_GPIO_Port, MOTOR_A_2_Pin, RESET);
        HAL_GPIO_WritePin(MOTOR_B_1_GPIO_Port, MOTOR_B_1_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_B_2_GPIO_Port, MOTOR_B_2_Pin, RESET);
        break;
      case MOTOR_LEFT:
        PID_Start = 0x01;
        Light_Start = 0x00;
        OpenMV_Start = 0x00;
        HAL_GPIO_WritePin(MOTOR_A_1_GPIO_Port, MOTOR_A_1_Pin, RESET);
        HAL_GPIO_WritePin(MOTOR_A_2_GPIO_Port, MOTOR_A_2_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_B_1_GPIO_Port, MOTOR_B_1_Pin, RESET);
        HAL_GPIO_WritePin(MOTOR_B_2_GPIO_Port, MOTOR_B_2_Pin, SET);
        break;
      case MOTOR_BACK:
        PID_Start = 0x01;
        HAL_GPIO_WritePin(MOTOR_A_1_GPIO_Port, MOTOR_A_1_Pin, RESET);
        HAL_GPIO_WritePin(MOTOR_A_2_GPIO_Port, MOTOR_A_2_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_B_1_GPIO_Port, MOTOR_B_1_Pin, SET);
        HAL_GPIO_WritePin(MOTOR_B_2_GPIO_Port, MOTOR_B_2_Pin, RESET);
        break;
      default:
        PID_Start = 0x00;
        Motor_Dir = MOTOR_STOP;
        break;
    }
    // Write PWM
    __HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, PWM_A);
    __HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4, PWM_B);
    osDelay(100);
  }
  /* USER CODE END StartSenseTask */
}

/* USER CODE BEGIN Header_StartLogicTask */
/**
* @brief Function implementing the LogicTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartLogicTask */
void StartLogicTask(void const * argument)
{
  /* USER CODE BEGIN StartLogicTask */
  // Wait for medicine
  while(Chest == RESET){
    osDelay(100);
  }
  LIGHT_RED_ON;
  // If number is 1 or 2
  if(OpenMV_Num == 0x01 || OpenMV_Num == 0x02){
    Go_Forward_Time(6000);
    if(OpenMV_Num == 0x01){
      // Room 1
      Go_Left_Time();
      Go_Forward_Time(3900);
      while(Chest == RESET){
        osDelay(100);
      }
      LIGHT_RED_OFF;
      Go_Back_Time();
      Go_Forward_Time(3900);
      Go_Right_Time();
      Go_Forward_Time(6000);
    }
    if(OpenMV_Num == 0x02){
      // Room 2
      Go_Right_Time();
      Go_Forward_Time(3900);
      while(Chest == RESET){
        osDelay(100);
      }
      LIGHT_RED_OFF;
      Go_Back_Time();
      Go_Forward_Time(3900);
      Go_Left_Time();
      Go_Forward_Time(6000);
    }
  }
  // If number is 3, 5, 6, 7, 8
  if(OpenMV_Num != 0x01 && OpenMV_Num != 0x02){
    OpenMV_Dir = 0x00;
    Go_Forward_Time(6000);
    Go_Forward_Time(7200);
    // If car find the number at middle
    if(OpenMV_Dir != 0x00){
      if(OpenMV_Dir > 60){
        // Mid-Right
        Go_Right_Time();
        Go_Forward_Time(3900);
        while(Chest == RESET){
          osDelay(100);
        }
        LIGHT_RED_OFF;
        Go_Back_Time();
        Go_Forward_Time(3900);
        Go_Left_Time();
        Go_Forward_Time(7200);
        Go_Forward_Time(6000);
      }else{
        // Mid-Left
        Go_Left_Time();
        Go_Forward_Time(3900);
        while(Chest == RESET){
          osDelay(100);
        }
        LIGHT_RED_OFF;
        Go_Back_Time();
        Go_Forward_Time(3900);
        Go_Right_Time();
        Go_Forward_Time(7200);
        Go_Forward_Time(6000);
      }
    }
    // If car can not find the number at middle
    if(OpenMV_Dir == 0x00){
      Go_Forward_Time(7300);
      if(OpenMV_Dir == 0x00){
        // Can not find number
        Go_Back_Time();
        Go_Forward_Time(7300);
        Go_Forward_Time(7200);
        Go_Forward_Time(6000);
      }
      if(OpenMV_Dir > 60){
        OpenMV_Dir = 0x00;
        Go_Right_Time();
        Go_Forward_Time(7150);
        if(OpenMV_Dir == 0x00){
          // Can not find number
          Go_Back_Time();
          Go_Forward_Time(7150);
          Go_Left_Time();
          Go_Forward_Time(7300);
          Go_Forward_Time(7200);
          Go_Forward_Time(6000);
        }
        if(OpenMV_Dir > 60){
          // Right-Down
          Go_Right_Time();
          Go_Forward_Time(3900);
          while(Chest == RESET){
            osDelay(100);
          }
          LIGHT_RED_OFF;
          Go_Back_Time();
          Go_Forward_Time(3900);
          Go_Left_Time();
          Go_Forward_Time(7150);
          Go_Left_Time();
          Go_Forward_Time(7300);
          Go_Forward_Time(7200);
          Go_Forward_Time(6000);
        }
        else{
          // Right-Up
          Go_Left_Time();
          Go_Forward_Time(3900);
          while(Chest == RESET){
            osDelay(100);
          }
          LIGHT_RED_OFF;
          Go_Back_Time();
          Go_Forward_Time(3900);
          Go_Right_Time();
          Go_Forward_Time(7150);
          Go_Left_Time();
          Go_Forward_Time(7300);
          Go_Forward_Time(7200);
          Go_Forward_Time(6000);
        }
      }
      else{
        OpenMV_Dir = 0x00;
        Go_Left_Time();
        Go_Forward_Time(7150);
        if(OpenMV_Dir == 0x00){
          // Can not find number
          Go_Back_Time();
          Go_Forward_Time(7150);
          Go_Right_Time();
          Go_Forward_Time(7300);
          Go_Forward_Time(7200);
          Go_Forward_Time(6000);
        }
        if(OpenMV_Dir > 60){
          // Left-Up
          Go_Right_Time();
          Go_Forward_Time(3900);
          while(Chest == RESET){
            osDelay(100);
          }
          LIGHT_RED_OFF;
          Go_Back_Time();
          Go_Forward_Time(3900);
          Go_Left_Time();
          Go_Forward_Time(7150);
          Go_Right_Time();
          Go_Forward_Time(7300);
          Go_Forward_Time(7200);
          Go_Forward_Time(6000);
        }
        else{
          // Left-Down
          Go_Left_Time();
          Go_Forward_Time(3900);
          while(Chest == RESET){
            osDelay(100);
          }
          LIGHT_RED_OFF;
          Go_Back_Time();
          Go_Forward_Time(3900);
          Go_Right_Time();
          Go_Forward_Time(7150);
          Go_Right_Time();
          Go_Forward_Time(7300);
          Go_Forward_Time(7200);
          Go_Forward_Time(6000);
        }
      }
    }
  }
//  Go_Forward_Time(6000);
//  Go_Forward_Time(7700);
//  Go_Forward_Time(4290);
  /* Infinite loop */
  LIGHT_GREEN_ON;
  for(;;)
  {
    osDelay(100);
  }
  /* USER CODE END StartLogicTask */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM4 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM4) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

